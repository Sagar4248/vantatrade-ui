import React from "react";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900">
      <header className="p-6 border-b border-gray-700 flex justify-between items-center">
        <h1 className="text-3xl font-bold text-primary">VantaTrade</h1>
        <nav>
          <a href="#features" className="px-4 hover:text-secondary">Features</a>
          <a href="#pricing" className="px-4 hover:text-secondary">Pricing</a>
          <a href="#contact" className="px-4 hover:text-secondary">Contact</a>
        </nav>
      </header>

      <main className="flex-grow flex flex-col items-center justify-center px-4 text-center space-y-6">
        <h2 className="text-5xl font-extrabold text-white max-w-4xl">
          Your Ultimate Prop Trading Platform
        </h2>
        <p className="max-w-3xl text-gray-300 text-lg">
          Enroll, trade, and grow with VantaTrade. Cutting-edge tools and real-time insights to empower traders in India.
        </p>
        <button className="bg-primary px-6 py-3 rounded-full font-semibold hover:bg-secondary transition">
          Get Started
        </button>
      </main>

      <section id="features" className="bg-gray-800 py-12 px-6 text-white max-w-5xl mx-auto rounded-lg mt-16">
        <h3 className="text-3xl font-bold mb-8">Features</h3>
        <ul className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
          <li>
            <h4 className="font-semibold text-xl mb-2">Real-time Trade Analytics</h4>
            <p className="text-gray-300">Track your trades and performance with detailed analytics and insights.</p>
          </li>
          <li>
            <h4 className="font-semibold text-xl mb-2">Nominal Enrollment Fee</h4>
            <p className="text-gray-300">Start trading with a low upfront fee and get access to funded accounts.</p>
          </li>
          <li>
            <h4 className="font-semibold text-xl mb-2">Payouts & Rewards</h4>
            <p className="text-gray-300">Earn payouts based on your consistent performance with transparent metrics.</p>
          </li>
        </ul>
      </section>

      <section id="pricing" className="py-12 px-6 max-w-4xl mx-auto">
        <h3 className="text-3xl font-bold text-white mb-8 text-center">Pricing</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-white">
          <div className="bg-gray-700 rounded-lg p-6 text-center">
            <h4 className="text-2xl font-semibold mb-4">Free Trial Account</h4>
            <p className="mb-6">Test your skills with a free $10k demo funded account.</p>
            <button className="bg-primary px-4 py-2 rounded hover:bg-secondary transition">Enroll Free</button>
          </div>
          <div className="bg-gray-700 rounded-lg p-6 text-center">
            <h4 className="text-2xl font-semibold mb-4">Standard Account</h4>
            <p className="mb-6">50k USD funded account for just ₹4,000 enrollment fee.</p>
            <button className="bg-primary px-4 py-2 rounded hover:bg-secondary transition">Get Started</button>
          </div>
          <div className="bg-gray-700 rounded-lg p-6 text-center">
            <h4 className="text-2xl font-semibold mb-4">Premium Account</h4>
            <p className="mb-6">100k USD funded account with exclusive perks.</p>
            <button className="bg-primary px-4 py-2 rounded hover:bg-secondary transition">Contact Us</button>
          </div>
        </div>
      </section>

      <footer id="contact" className="bg-gray-800 py-6 mt-16 text-center text-gray-400">
        © 2025 VantaTrade. All rights reserved.
      </footer>
    </div>
  );
}